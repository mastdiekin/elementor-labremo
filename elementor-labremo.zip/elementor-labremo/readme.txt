=== elementor-labremo ===
Contributors: mastdiekin
Tags:
Requires at least: 3.0.1
Tested up to: 5.2.2
Requires PHP: 5.2.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom Elementor Plugin for Labremo Gym theme.

== Changelog ==

= 1.2.2 =
*Release Date - 9 December 2019*

* fix autoupdater

= 1.2.0 =
*Release Date - 9 December 2019*

* init plugin


[View the full changelog](https://github.com/mastdiekin/elementor-labremo/blob/master/CHANGELOG.md)

== Upgrade Notice ==
